package com.example.inventoryappv1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

//Public class - MainActivity
public class MainActivity extends AppCompatActivity {
    private Button login, register;
    private EditText username, password;
    private DatabaseLogs db;

    //onCreate - Assign layout features, create database log
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Assign layout features
        username = findViewById(R.id.editTextTextUsername);
        password = findViewById(R.id.editTextTextPassword);
        login = findViewById(R.id.loginButton);
        register = findViewById(R.id.registerButton);

        //new database log
        db = new DatabaseLogs(this);

        //onclick listener for login button
        login.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                //gets user name and password string
                String userString = username.getText().toString();
                String passString = password.getText().toString();

                //check fields are not empty, and sends Toasts, if conditional passes, push next activity
                if (userString.equals("") || passString.equals("")){
                    Toast.makeText(getApplicationContext(),"Fields are empty", Toast.LENGTH_SHORT).show();
                }
                else{
                    Boolean UserExistsCheck = db.UserExistsCheck(userString);
                    Boolean PassExistsCheck = db.UserPasswordCheck(userString, passString);

                    if (UserExistsCheck == true && PassExistsCheck == true){
                        DatabaseActivityOpen();
                    }
                    else{
                        Toast.makeText(getApplicationContext(),"Invalid User/Password", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        //onclick listener for register button
        register.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                //get username and pass
                String userString = username.getText().toString();
                String passString = password.getText().toString();

                //check fields are not empty, if username exists, if not adds username/password to Database
                if (userString.equals("") || passString.equals("")){
                    Toast.makeText(getApplicationContext(),"Fields are empty", Toast.LENGTH_SHORT).show();
                }
                else{
                    Boolean UserExistsCheck = db.UserExistsCheck(userString);

                    if (!UserExistsCheck == true){
                        Boolean insert = db.insert(userString, passString);
                        if (insert == true){
                            Toast.makeText(getApplicationContext(),"Registered", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Toast.makeText(getApplicationContext(),"User Name Already Exists", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    //Next activity - Main Database activity
    public void DatabaseActivityOpen() {
        Intent intent = new Intent(this, DatabaseActivity.class);
        startActivity(intent);
    }

}