package com.example.inventoryappv1;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseItems extends SQLiteOpenHelper {

    public static final String DB_NAME = "DatabaseItems.db";

    public DatabaseItems(Context context) {
        super(context, "DatabaseItems.db", null, 1);
    }

    //Creates item and amount without primary key, so duplicate entries are allowed
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create Table inventory(item string, amount string)");
    }

    //Checks if table exists and enables deletion of table
    @Override
    public void onUpgrade(SQLiteDatabase ADB, int oldVer, int newVer) {
        ADB.execSQL("drop Table if exists inventory");

    }

    //insert method to add to inventory database
    //also returns a boolean for other checks
    public Boolean insert(String item, String amount){
        SQLiteDatabase ADB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("item", item);
        contentValues.put("amount", amount);
        long result = ADB.insert("inventory", null, contentValues);

        if (result == -1)
            return false;
        else
            return true;
    }

    //Clears database
    public void delete() {
        SQLiteDatabase ADB = this.getWritableDatabase();
        String clearDBQuery = "DELETE FROM " + "inventory";
        ADB.execSQL(clearDBQuery);
    }

    //Returns a list to rebuild Inventory on database activity
    public List<String> copyFromDB() {

        //initialize list
        List<String> TextListEdit = new ArrayList<String>();
        SQLiteDatabase ADB = this.getWritableDatabase();
        Cursor cursor = ADB.rawQuery("SELECT * FROM " + "inventory", null);

        //Iterates SQL database, adds data to list
        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()) {
                @SuppressLint("Range") String tempItem = cursor.getString(cursor.getColumnIndex("item"));
                @SuppressLint("Range") String tempAmount = cursor.getString(cursor.getColumnIndex("amount"));

                TextListEdit.add(tempItem);
                TextListEdit.add(tempAmount);
                cursor.moveToNext();
            }
        }

        //close cursor when finished
        cursor.close();

        //returns created list
        return TextListEdit;
    }
}
