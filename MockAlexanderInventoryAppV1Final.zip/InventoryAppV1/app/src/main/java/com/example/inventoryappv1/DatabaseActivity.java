package com.example.inventoryappv1;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Switch;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;

//Public class DatabaseActivity - initialize variables
public class DatabaseActivity extends AppCompatActivity {
    private Button addItemButton, saveInventoryButton, AlertButton;
    private ImageButton deleteItemButton;
    private Switch AlertSwitch;
    private EditText itemName, itemAmount;
    private List<View> listViews = new ArrayList<>();
    private int index = 0;
    private DatabaseItems db;

    //onCreate saved instance
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);

        //Create new database item object
        db = new DatabaseItems(this);


        //Pass in empty fields, Adds listener for add Item button
        addItemButton = findViewById(R.id.addItemButton);
        addItemButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {addItemButton("","");}
        });

        //Add listener for add save button, Will save current inventory into item database
       saveInventoryButton = findViewById(R.id.saveButton);
        saveInventoryButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {saveInventoryButton();}
        });

        //Add listener for notification switch, will call method for pushing notification
        AlertSwitch = findViewById(R.id.AlertSwitch);
        AlertSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {PermissionRequest();}
        });


        //Initializes data on activity start, Calls to methods which pull the current item database
        addInitialDB(db.copyFromDB());

    }
    //Requests permission to send SMS
    public void PermissionRequest(){
        SmsPermissionRequest();
    }

    //Load initial database on activity launch
    //Takes in a list, iterates over the stored Item database
    //Values pass into the addItemButton method to recreate current inventory
    public void addInitialDB(List<String> editTextList){

        for (int i = 0; i < editTextList.size(); i += 2){
            addItemButton(editTextList.get(i), editTextList.get(i+1));
        }

    }

    //Adds new row of inventory, default values are empty
    public void addItemButton(String setItem, String setAmount) {

        //pushes activity_get_layout to scroll view
        LayoutInflater inflater = getLayoutInflater();
        View view = inflater.inflate(R.layout.activity_get_layout, null);
        LinearLayout inventory = findViewById(R.id.scrollViewLayout);

        //Edits database value item
        EditText editItem = view.findViewById(R.id.getUpdateItem);
        if (setItem != ""){
            editItem.setText(setItem);
        }
        //Edits database value quantity
        EditText editAmount = view.findViewById(R.id.getUpdateQuantity);
        if (setItem != ""){
            editAmount.setText(setAmount);
        }

        //Adds view into the scrollview
        inventory.addView(view);

        //adds view into list view for later retrieval
        listViews.add(view);

        //tracks the current index for delete button listener
        index = listViews.indexOf(view);

        //Delete button Listener
        deleteItemButton = view.findViewById(R.id.deleteItemButton);
        deleteItemButton.setOnClickListener(new View.OnClickListener(){
            View currView = listViews.get(index);
            @Override
            public void onClick(View view) {
                deleteItemButton(currView);}
        });

    }

    //Delete Button method
    public void deleteItemButton(View currView){

        //removes row from list/inventory
        LinearLayout inventory = findViewById(R.id.scrollViewLayout);
        listViews.remove(currView);
        inventory.removeView(currView);

    }

    //writes data to database
    //sends notification with permissions on 0 amount of inventory item
    public void saveInventoryButton() {
        //clears the current database
        db.delete();

        //iterates through list of views, gets and converts values to strings
        //calls insert function to rebuild SQL database
        for (int i = 0; i < listViews.size(); i++){

            itemName = listViews.get(i).findViewById(R.id.getUpdateItem);
            itemAmount = listViews.get(i).findViewById(R.id.getUpdateQuantity);

            String item = itemName.getText().toString();
            String amount = itemAmount.getText().toString();

            db.insert(item, amount);
            //Sends text message if amount of item is = 0
            if((ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) && amount.equals("0")){
                TextReminder(item);
            }

        }

        }



    //Permission Request used on clicking to add alerts
    //Will continue to ask on button click until user clicks allow
    private void SmsPermissionRequest() {
        String permission = Manifest.permission.SEND_SMS;
        int grant = ContextCompat.checkSelfPermission(this, permission);
        if (grant != PackageManager.PERMISSION_GRANTED) {
            String[] permission_list = new String[1];
            permission_list[0] = permission;
            ActivityCompat.requestPermissions(this, permission_list, 1);
        }
    }
    //Send text message to user
    //Replace destination address to correct phone #
    public void TextReminder (String restock){
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage("15555215554", null, "***Reminder*** Restock " + restock , null, null);
    }


}