package com.example.inventoryappv1;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;
import android.database.Cursor;
import android.content.ContentValues;


public class DatabaseLogs extends SQLiteOpenHelper {

    public static final String DB_NAME = "DatabaseLogs.db";

    public DatabaseLogs(Context context) {
        super(context, "DatabaseLogs.db", null, 1);
    }

    //Creates user as primary key and password
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create Table users(username TEXT primary key, password TEXT)");
    }

    //Checks existence and enables deletion of table
    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int oldVer, int newVer) {
        MyDB.execSQL("drop Table if exists users");

    }

    //insert adds to Login database
    public Boolean insert(String username, String password){

        ContentValues contentValues = new ContentValues();
        SQLiteDatabase MyDB = this.getWritableDatabase();

        //for Username and pass
        contentValues.put("username", username);
        contentValues.put("password", password);

        long result = MyDB.insert("users", null, contentValues);
        //return boolean checks
        if (result == -1)
            return false;
        else
            return true;
    }

    //checks username
    public Boolean UserExistsCheck(String username){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ?", new String[] {username});
        if(cursor.getCount() > 0)
            return true;
        else
            return false;
    }

    //checks a password/username combination
    public Boolean UserPasswordCheck(String username, String password){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ? and password = ?", new String[] {username,password});
        if(cursor.getCount() > 0)
            return true;
        else
            return false;
    }

}
